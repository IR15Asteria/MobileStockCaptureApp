﻿namespace MobileStockCapture
{
    partial class FrmStockCaptureApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblOutput = new Label();
            lblMobileCode = new Label();
            lblMake = new Label();
            lblQuantity = new Label();
            lsbMobilePhones = new ListBox();
            gpbInformation = new GroupBox();
            btnFind = new Button();
            btnDelete = new Button();
            btnAdd = new Button();
            txtMake = new TextBox();
            txtQuantity = new TextBox();
            txtMobileCode = new TextBox();
            gpbInformation.SuspendLayout();
            SuspendLayout();
            // 
            // lblOutput
            // 
            lblOutput.AutoSize = true;
            lblOutput.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblOutput.ForeColor = Color.White;
            lblOutput.Location = new Point(12, 18);
            lblOutput.Name = "lblOutput";
            lblOutput.Size = new Size(117, 32);
            lblOutput.TabIndex = 0;
            lblOutput.Text = "Output:";
            // 
            // lblMobileCode
            // 
            lblMobileCode.AutoSize = true;
            lblMobileCode.Font = new Font("Arial Rounded MT Bold", 12F);
            lblMobileCode.Location = new Point(6, 31);
            lblMobileCode.Name = "lblMobileCode";
            lblMobileCode.Size = new Size(137, 23);
            lblMobileCode.TabIndex = 1;
            lblMobileCode.Text = "Mobile Code:";
            // 
            // lblMake
            // 
            lblMake.AutoSize = true;
            lblMake.Font = new Font("Arial Rounded MT Bold", 12F);
            lblMake.Location = new Point(6, 74);
            lblMake.Name = "lblMake";
            lblMake.Size = new Size(73, 23);
            lblMake.TabIndex = 2;
            lblMake.Text = "Make: ";
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Font = new Font("Arial Rounded MT Bold", 12F);
            lblQuantity.Location = new Point(6, 114);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(103, 23);
            lblQuantity.TabIndex = 3;
            lblQuantity.Text = "Quantity: ";
            // 
            // lsbMobilePhones
            // 
            lsbMobilePhones.FormattingEnabled = true;
            lsbMobilePhones.HorizontalScrollbar = true;
            lsbMobilePhones.ItemHeight = 27;
            lsbMobilePhones.Location = new Point(12, 292);
            lsbMobilePhones.Name = "lsbMobilePhones";
            lsbMobilePhones.ScrollAlwaysVisible = true;
            lsbMobilePhones.Size = new Size(600, 247);
            lsbMobilePhones.TabIndex = 4;
            // 
            // gpbInformation
            // 
            gpbInformation.BackColor = Color.MediumSeaGreen;
            gpbInformation.Controls.Add(btnFind);
            gpbInformation.Controls.Add(btnDelete);
            gpbInformation.Controls.Add(btnAdd);
            gpbInformation.Controls.Add(txtMake);
            gpbInformation.Controls.Add(txtQuantity);
            gpbInformation.Controls.Add(txtMobileCode);
            gpbInformation.Controls.Add(lblMobileCode);
            gpbInformation.Controls.Add(lblMake);
            gpbInformation.Controls.Add(lblQuantity);
            gpbInformation.Location = new Point(12, 71);
            gpbInformation.Name = "gpbInformation";
            gpbInformation.Size = new Size(600, 215);
            gpbInformation.TabIndex = 5;
            gpbInformation.TabStop = false;
            gpbInformation.Text = "Information:";
            // 
            // btnFind
            // 
            btnFind.Location = new Point(474, 169);
            btnFind.Name = "btnFind";
            btnFind.Size = new Size(120, 40);
            btnFind.TabIndex = 9;
            btnFind.Text = "Find";
            btnFind.UseVisualStyleBackColor = true;
            btnFind.Click += btnFind_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(254, 169);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(120, 40);
            btnDelete.TabIndex = 8;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.White;
            btnAdd.Location = new Point(6, 169);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(120, 40);
            btnAdd.TabIndex = 7;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // txtMake
            // 
            txtMake.Location = new Point(149, 68);
            txtMake.Name = "txtMake";
            txtMake.Size = new Size(420, 34);
            txtMake.TabIndex = 6;
            // 
            // txtQuantity
            // 
            txtQuantity.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtQuantity.Location = new Point(149, 111);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(420, 31);
            txtQuantity.TabIndex = 5;
            // 
            // txtMobileCode
            // 
            txtMobileCode.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtMobileCode.Location = new Point(149, 28);
            txtMobileCode.Name = "txtMobileCode";
            txtMobileCode.Size = new Size(420, 31);
            txtMobileCode.TabIndex = 4;
            // 
            // FrmStockCaptureApp
            // 
            AutoScaleDimensions = new SizeF(14F, 27F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SeaGreen;
            ClientSize = new Size(623, 553);
            Controls.Add(gpbInformation);
            Controls.Add(lsbMobilePhones);
            Controls.Add(lblOutput);
            Font = new Font("Arial Rounded MT Bold", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(5, 4, 5, 4);
            MaximizeBox = false;
            Name = "FrmStockCaptureApp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Mobile Stock Capture Application";
            gpbInformation.ResumeLayout(false);
            gpbInformation.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblOutput;
        private Label lblMobileCode;
        private Label lblMake;
        private Label lblQuantity;
        private ListBox lsbMobilePhones;
        private GroupBox gpbInformation;
        private Button btnFind;
        private Button btnDelete;
        private Button btnAdd;
        private TextBox txtMake;
        private TextBox txtQuantity;
        private TextBox txtMobileCode;
    }
}
