﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MobileStockCapture
{
    internal class MobilePhone
    {
        // Attributes of class
        private int _code {  get; set; }
        private string _make { get; set; }
        private int _quantity { get; set; }

        // Constructor for MobilePhone class that will instantiate object
        public MobilePhone(int code, string make, int quantity)
        {
            _code = code;
            _make = make;
            _quantity = quantity;
        }

        // Getter methods for attributes
        public int GetCode()
        {
            return _code;
        }

        public string GetMake()
        {
            return _make;
        }

        public int GetQuantity()
        {
            return _quantity;
        }

        // Setter methods for attributes
        public void SetCode(int code)
        {
            _code = code;
        }

        public void SetMake(string make)
        {
            _make = make;
        }

        public void SetQuantity(int quantity)
        {
            _quantity = quantity;
        }

        // Overriding ToString() method of object class
        public override string ToString()
        {
            return $"{_code} | {_make} | {_quantity}";
        }
    }
}
