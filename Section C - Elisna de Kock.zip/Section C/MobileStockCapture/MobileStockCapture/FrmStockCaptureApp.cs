//*
//  Dear Sir/Madam,
//      We haven't dealt with using SQL and databases in class.
//      Thus, I've struggled to implement the code to save my data to the table specified in the Summative Assessment's Section C.
//      However, I used a list, called tblMobilePhones, as a substitute for the table.
//*//

namespace MobileStockCapture
{
    public partial class FrmStockCaptureApp : Form
    {
        // See top comment ====================================================================================================================================================
        List<MobilePhone> tblMobilePhones = new List<MobilePhone>();

        public FrmStockCaptureApp()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Try to execute code, catch any exceptions and handle it gracefully
            try
            {
                // Validate input fields
                if (string.IsNullOrWhiteSpace(txtMobileCode.Text) || !int.TryParse(txtMobileCode.Text, out int code))
                {
                    // If Code is entered invalidly, this block
                    MessageBox.Show("Please enter a valid, numeric value in the MOBILE CODE input field.");
                    return;
                }

                // Loop through list object to check if it already contains this code
                // Prevents duplicates
                foreach (MobilePhone phone in tblMobilePhones)
                {
                    if (code == phone.GetCode())
                    {
                        MessageBox.Show("This code already exists. Try entering another code.");
                        return;
                    }
                }

                // Checks that txtMake is not left empty
                if (string.IsNullOrWhiteSpace(txtMake.Text))
                {
                    // Display error message
                    MessageBox.Show("Please enter a value for the MAKE input field. It cannot be empty.");
                    return;
                }

                // Get make from input field
                string make = txtMake.Text;

                // Ensures txtQuantity is not empty and is a valid numeric value
                if (string.IsNullOrWhiteSpace(txtQuantity.Text) || !int.TryParse(txtQuantity.Text, out int quantity))
                {
                    // Error message to display
                    MessageBox.Show("Please enter a value for the QUANTITY field. It cannot be left empty and it must be a number.");
                    return;
                }

                // Display success message, mobile phone has been added
                lblOutput.Text = $"Record Added: {code} | {make} | {quantity}";

                // Create a new MobilePhone object and set its properties using the input values
                MobilePhone newPhone = new MobilePhone(code, make, quantity);

                // Add the new mobile phone to the list
                tblMobilePhones.Add(newPhone);

                // Add Mobile phone to visible output to confirm success
                lsbMobilePhones.Items.Add(newPhone.ToString());

                // Clean up
                Clear();

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occured." + ex.Message);
            }
        }

        public void Clear()
        {
            // Clear all fields
            txtMobileCode.Clear();
            txtMake.Clear();
            txtQuantity.Clear();

            // Set focus to top most input field
            txtMobileCode.Focus();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Get the code from the input field
            if (string.IsNullOrWhiteSpace(txtMobileCode.Text) || !int.TryParse(txtMobileCode.Text, out int code))
            {
                MessageBox.Show("Please enter a valid, numeric value in the MOBILE CODE input field.");
                return;
            }

            // Search for the mobile phone with the specified code
            MobilePhone phoneToDelete = tblMobilePhones.FirstOrDefault(p => p.GetCode() == code);
            if (phoneToDelete != null)
            {
                // Confirm deletion
                DialogResult result = MessageBox.Show($"Are you sure you want to delete the record: {phoneToDelete.ToString()}?", "Confirm Deletion", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    // Display found message
                    MessageBox.Show("Record was found.");

                    // Remove the phone from the list AND listbox
                    tblMobilePhones.Remove(phoneToDelete);
                    lsbMobilePhones.Items.Remove(phoneToDelete.ToString());

                    // Success message on output label
                    lblOutput.Text = $"Record Deleted at {code}.";
                }
            }
            else
            {
                // If there is no such phone in the list
                MessageBox.Show("Record not found.");
            }
        }

        private void btnFind_Click(object sender, EventArgs e)
        {

        }
    }
}
