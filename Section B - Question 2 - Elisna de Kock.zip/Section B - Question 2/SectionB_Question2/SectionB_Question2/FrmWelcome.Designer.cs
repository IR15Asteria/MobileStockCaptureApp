﻿namespace SectionB_Question2
{
    partial class FrmWelcome
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblUserName = new Label();
            txtUserName = new TextBox();
            btnGreet = new Button();
            SuspendLayout();
            // 
            // lblUserName
            // 
            lblUserName.AutoSize = true;
            lblUserName.Location = new Point(19, 42);
            lblUserName.Margin = new Padding(4, 0, 4, 0);
            lblUserName.Name = "lblUserName";
            lblUserName.Size = new Size(249, 32);
            lblUserName.TabIndex = 0;
            lblUserName.Text = "Enter your name:";
            // 
            // txtUserName
            // 
            txtUserName.ForeColor = Color.Crimson;
            txtUserName.Location = new Point(104, 77);
            txtUserName.Margin = new Padding(4);
            txtUserName.Name = "txtUserName";
            txtUserName.Size = new Size(417, 39);
            txtUserName.TabIndex = 1;
            // 
            // btnGreet
            // 
            btnGreet.BackColor = Color.Crimson;
            btnGreet.ForeColor = Color.LavenderBlush;
            btnGreet.Location = new Point(376, 125);
            btnGreet.Margin = new Padding(4);
            btnGreet.Name = "btnGreet";
            btnGreet.Size = new Size(146, 47);
            btnGreet.TabIndex = 2;
            btnGreet.Text = "Greet!";
            btnGreet.UseVisualStyleBackColor = false;
            btnGreet.Click += btnGreet_Click;
            // 
            // FrmWelcome
            // 
            AutoScaleDimensions = new SizeF(17F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleVioletRed;
            ClientSize = new Size(582, 253);
            Controls.Add(btnGreet);
            Controls.Add(txtUserName);
            Controls.Add(lblUserName);
            Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(6, 5, 6, 5);
            MaximizeBox = false;
            Name = "FrmWelcome";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Welcome!";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblUserName;
        private TextBox txtUserName;
        private Button btnGreet;
    }
}
