namespace SectionB_Question2
{
    public partial class FrmWelcome : Form
    {
        public FrmWelcome()
        {
            InitializeComponent();
        }

        private void btnGreet_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate that name has been entered into textfield
                if (string.IsNullOrWhiteSpace(txtUserName.Text))
                {
                    // Display error-message and allow user to try again
                    MessageBox.Show("Please enter a name to be greeted!");
                    return;
                }

                // Collect user's name and assign it to a variable
                string userName = txtUserName.Text;

                // Continues if name is entered
                MessageBox.Show($"Hello, {userName}!");
            }catch(Exception ex)
            {
                // General exception handling
                MessageBox.Show("An error occured." + ex.Message);
            }

        }
    }
}
