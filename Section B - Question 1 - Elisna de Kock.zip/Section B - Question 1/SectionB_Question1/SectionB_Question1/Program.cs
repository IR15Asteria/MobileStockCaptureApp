﻿// This console application was created by: Elisna de Kock

try
{
    // Display welcoming message
    Console.WriteLine("Welcome to the Structure of a C# Program Demo");

    // Prompt the user to enter their name
    Console.WriteLine("Enter your name: ");

    // Read the enter value from the console and asssign it to a variable
    string userName = Console.ReadLine().Trim();


    // Display message including user's name
    Console.WriteLine($"Hello, {userName}!\n");

    // Display The Program Structure list
    Console.WriteLine("""
    Program Structure Demonstrated:
    1. using System : imports functionality
    2. namespace : organizes code
    3. class Program : container for code
    4. Main() : entry point of program
    5. Comments : explain logic and documentation
    """);
}
catch (Exception e)
{
    // General exception handling
    Console.WriteLine("An error occured." + e.Message);
}
finally
{
    // Display ending message - this message will always print to console after program executed.
    Console.WriteLine("\nProgram executed successfully\n");
}